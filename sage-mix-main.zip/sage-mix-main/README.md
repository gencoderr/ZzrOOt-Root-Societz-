[Roots Sage](https://github.com/roots/sage) Starter Theme with [Laravel Mix](https://laravel-mix.com/) instead of Bud

Steps:
- Download and run composer install and npm install
- Activate Theme
- Edit webpack.mix.js to suit your environment
- Edit public/entrypoints.json to add your scripts and stylesheets
- run npx mix

For more Information on Sage visit https://roots.io/sage/
For more Information on Laravel Mix visit https://laravel-mix.com/



