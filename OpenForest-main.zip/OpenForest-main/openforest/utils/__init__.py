import pathlib

OPENFOREST_HOME = pathlib.Path(__file__).resolve().parents[1]
