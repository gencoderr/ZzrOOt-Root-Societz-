export const AES_256_GCM = 'aes-256-gcm';

export const ENCRYPTION_ALGORITHMS = [AES_256_GCM] as const;
