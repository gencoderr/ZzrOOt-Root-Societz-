export const DEFAULT_API_BASE_URL = 'https://enclosed.cc';
