import type { getConfig } from './config';

export type Config = ReturnType<typeof getConfig>;
