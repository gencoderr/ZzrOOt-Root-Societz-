import type { defineTask } from './tasks.models';

export type TaskDefinition = ReturnType<typeof defineTask>;
