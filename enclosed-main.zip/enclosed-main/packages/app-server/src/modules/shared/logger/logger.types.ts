import type { createLogger } from './logger';

export type Logger = ReturnType<typeof createLogger>;
