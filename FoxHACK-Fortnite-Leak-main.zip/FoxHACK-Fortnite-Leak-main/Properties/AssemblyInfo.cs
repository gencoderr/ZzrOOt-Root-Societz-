﻿using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security.Permissions;

[assembly: AssemblyCompany("wJhVwAwZY")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright ©  2021 wJhVwAwZY")]
[assembly: AssemblyDescription("HWdTnFx")]
[assembly: AssemblyFileVersion("2.23.48.39")]
[assembly: AssemblyProduct("HWdTnFx")]
[assembly: AssemblyTitle("HWdTnFx")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("2.23.48.39")]
[assembly: CompilationRelaxations(8)]
[assembly: ComVisible(false)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: Guid("3c88cb0d-a211-4db3-bb3d-83cd9b56aa8d")]
[assembly: NeutralResourcesLanguage("en-us")]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification=true)]
