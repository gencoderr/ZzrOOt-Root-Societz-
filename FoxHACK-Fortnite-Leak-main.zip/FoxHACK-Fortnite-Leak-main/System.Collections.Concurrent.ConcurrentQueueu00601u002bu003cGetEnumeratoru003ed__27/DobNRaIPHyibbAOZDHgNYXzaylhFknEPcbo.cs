using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace System.Collections.Concurrent.ConcurrentQueueu00601u002bu003cGetEnumeratoru003ed__27
{
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")]
	internal sealed class DobNRaIPHyibbAOZDHgNYXzaylhFknEPcbo : ApplicationSettingsBase
	{
		private static DobNRaIPHyibbAOZDHgNYXzaylhFknEPcbo System.ComponentModel.Design.IComponentDiscoveryService;

		public static DobNRaIPHyibbAOZDHgNYXzaylhFknEPcbo System.ComponentModel.Design.Serialization.ComponentSerializationService
		{
			get
			{
				return DobNRaIPHyibbAOZDHgNYXzaylhFknEPcbo.System.ComponentModel.Design.IComponentDiscoveryService;
			}
		}

		static DobNRaIPHyibbAOZDHgNYXzaylhFknEPcbo()
		{
			DobNRaIPHyibbAOZDHgNYXzaylhFknEPcbo.System.ComponentModel.Design.IComponentDiscoveryService = (DobNRaIPHyibbAOZDHgNYXzaylhFknEPcbo)SettingsBase.Synchronized(new DobNRaIPHyibbAOZDHgNYXzaylhFknEPcbo());
		}

		public DobNRaIPHyibbAOZDHgNYXzaylhFknEPcbo()
		{
		}
	}
}