using System;
using System.Collections.Generic;

namespace System.ComponentModel.MaskedTextProvider
{
	internal static class KcCuQEfFoueslppzwxKnwAbqQACaKVjXFmP
	{
		public static List<byte> System.Linq.Parallel.NullableIntMinMaxAggregationOperator+NullableIntMinMaxAggregationOperatorEnumerator;

		static KcCuQEfFoueslppzwxKnwAbqQACaKVjXFmP()
		{
			KcCuQEfFoueslppzwxKnwAbqQACaKVjXFmP.System.Linq.Parallel.NullableIntMinMaxAggregationOperator+NullableIntMinMaxAggregationOperatorEnumerator = new List<byte>();
		}

		private static double 00波ۄ7(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 018豆留(double num)
		{
			return Math.Round(num);
		}

		private static double 04ﻬے波(double num)
		{
			return Math.Floor(num);
		}

		private static double 0ٱ大ڙﻐ(double num)
		{
			return Math.Floor(num);
		}

		private static double 0ﺁ克ڿٯ(double num)
		{
			return Math.Round(num);
		}

		private static double 0ڟۅﻌﻬ(double num)
		{
			return Math.Floor(num);
		}

		private static double 0ٯګۄﻬ(double num)
		{
			return Math.Floor(num);
		}

		private static double 0波8ڙڙ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 11斯ﻐ2(double num)
		{
			return Math.Floor(num);
		}

		private static double 13ٯٱۄ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 13ﻲ克6(double num)
		{
			return Math.Floor(num);
		}

		private static double 1ٺ艾大ڟ(double num)
		{
			return Math.Floor(num);
		}

		private static double 1ڈﻐﺈﻲ(double num)
		{
			return Math.Floor(num);
		}

		private static double 1ٯۄ留4(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 1ڪﻐ91(double num)
		{
			return Math.Floor(num);
		}

		private static double 1ےﺁ96(double num)
		{
			return Math.Round(num);
		}

		private static double 21ٺ5艾(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 27ﺂ6ڔ(double num)
		{
			return Math.Floor(num);
		}

		private static double 27艾ﻬړ(double num)
		{
			return Math.Round(num);
		}

		private static double 2ﺈ9儿克(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 2ﺇﻬۄ1(double num)
		{
			return Math.Round(num);
		}

		private static double 2ﺂ波ڙ8(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 2ږﻬۅ艾(double num)
		{
			return Math.Round(num);
		}

		private static double 2ڟ儿ٺڑ(double num)
		{
			return Math.Floor(num);
		}

		private static double 2ﻬڈٯڪ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 2ۄ9ۋڙ(double num)
		{
			return Math.Floor(num);
		}

		private static double 34艾ڙڪ(double num)
		{
			return Math.Round(num);
		}

		private static double 37ٯۈڕ(double num)
		{
			return Math.Round(num);
		}

		private static double 3ٱ斯ڋ波(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 3ڈڋڟﺂ(double num)
		{
			return Math.Round(num);
		}

		private static double 3ږﭢﻐۅ(double num)
		{
			return Math.Round(num);
		}

		private static double 3ګڈڋګ(double num)
		{
			return Math.Round(num);
		}

		private static double 3ﻬ儿大波(double num)
		{
			return Math.Floor(num);
		}

		private static double 47ګ波ړ(double num)
		{
			return Math.Floor(num);
		}

		private static double 4ﻬ5ړڪ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 4ٷ2留2(double num)
		{
			return Math.Floor(num);
		}

		private static double 4ے2ﻌ克(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 4艾ﺈ波克(double num)
		{
			return Math.Round(num);
		}

		private static double 50留波ڑ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 5ﺂ9۶3(double num)
		{
			return Math.Floor(num);
		}

		private static double 604留5(double num)
		{
			return Math.Floor(num);
		}

		private static double ۶0ڙ艾ﺇ(double num)
		{
			return Math.Round(num);
		}

		private static double ۶1ﻐ豆ﻬ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ۶2ڙ10(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 62克ڪ留(double num)
		{
			return Math.Round(num);
		}

		private static double 635ﻌﺂ(double num)
		{
			return Math.Floor(num);
		}

		private static double 66大波6(double num)
		{
			return Math.Round(num);
		}

		private static double 69ﻲﻐ留(double num)
		{
			return Math.Round(num);
		}

		private static double 6ڋ克4ے(double num)
		{
			return Math.Round(num);
		}

		private static double ۶ږ波波ے(double num)
		{
			return Math.Round(num);
		}

		private static double ۶ﻌ1儿ڟ(double num)
		{
			return Math.Floor(num);
		}

		private static double 6ګڙۈږ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ۶ۅڪ波1(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 6克ٱ8ڟ(double num)
		{
			return Math.Floor(num);
		}

		private static double ۶留ﻬٷے(double num)
		{
			return Math.Round(num);
		}

		private static double 737ڙﻬ(double num)
		{
			return Math.Floor(num);
		}

		private static double 7ٱ留豆斯(double num)
		{
			return Math.Floor(num);
		}

		private static double 7ﭢ埃ڑ7(double num)
		{
			return Math.Floor(num);
		}

		private static double 7ګ3克۶(double num)
		{
			return Math.Floor(num);
		}

		private static double 7ګڙۋ1(double num)
		{
			return Math.Floor(num);
		}

		private static double 7ۅ15克(double num)
		{
			return Math.Floor(num);
		}

		private static double 7埃7ٺڿ(double num)
		{
			return Math.Floor(num);
		}

		private static double 7波ﻌڑٷ(double num)
		{
			return Math.Round(num);
		}

		private static double 83ۓ0ۈ(double num)
		{
			return Math.Floor(num);
		}

		private static double 8ڕڙ2ٱ(double num)
		{
			return Math.Floor(num);
		}

		private static double 8ڔڪڿۄ(double num)
		{
			return Math.Round(num);
		}

		private static double 8ﻐۋ波波(double num)
		{
			return Math.Floor(num);
		}

		private static double 8大ړﭢڔ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 95ٯ8ۈ(double num)
		{
			return Math.Round(num);
		}

		private static double 9ﺇ儿35(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 9ٯٱ9ﻌ(double num)
		{
			return Math.Round(num);
		}

		private static double 9ﻬڋﻌٺ(double num)
		{
			return Math.Round(num);
		}

		private static double 9ۓڔﺇڿ(double num)
		{
			return Math.Floor(num);
		}

		[STAThread]
		private static void Main()
		{
			// 
			// Current member / type: System.Void System.ComponentModel.MaskedTextProvider.KcCuQEfFoueslppzwxKnwAbqQACaKVjXFmP::Main()
			// File path: C:\Users\god_o\Desktop\FoxHACK.exe
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void Main()
			// 
			// Object reference not set to an instance of an object.
			//    at ..( ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RemovePrivateImplemetnationDetailsStep.cs:line 149
			//    at ..( ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RemovePrivateImplemetnationDetailsStep.cs:line 48
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RemovePrivateImplemetnationDetailsStep.cs:line 33
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\CombinedTransformerStep.cs:line 193
			//    at ..(ICodeNode ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 123
			//    at ..Visit(ICodeNode ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 276
			//    at ..(BinaryExpression ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 529
			//    at ..(BinaryExpression ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\CombinedTransformerStep.cs:line 183
			//    at ..(BinaryExpression ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\CombinedTransformerStep.cs:line 101
			//    at ..(ICodeNode ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 97
			//    at ..Visit(ICodeNode ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 276
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 383
			//    at ..(ICodeNode ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 59
			//    at ..Visit(ICodeNode ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 276
			//    at ..Visit[,]( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 286
			//    at ..Visit( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 317
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 337
			//    at ..(ICodeNode ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 49
			//    at ..Visit(ICodeNode ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 276
			//    at ..(IfStatement ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 361
			//    at ..(ICodeNode ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 55
			//    at ..Visit(ICodeNode ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 276
			//    at ..Visit[,]( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 286
			//    at ..Visit( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 317
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\BaseCodeTransformer.cs:line 337
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\CombinedTransformerStep.cs:line 44
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		private static double ٱٱ7ﻬٯ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ٱﻌڿۓ留(double num)
		{
			return Math.Floor(num);
		}

		private static double ٱۋﺁړﺇ(double num)
		{
			return Math.Round(num);
		}

		private static double ٱ留ﻌ8斯(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ٱ豆ٱڿﻬ(double num)
		{
			return Math.Round(num);
		}

		private static double ﺈ3ګڋ9(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﺈ5ﺈﭢ豆(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﺈ۶克2ﺁ(double num)
		{
			return Math.Round(num);
		}

		private static double ﺁ8ڋ7留(double num)
		{
			return Math.Floor(num);
		}

		private static double ﺂﺂٺ波ﻌ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﺈﺂﻬﺇۈ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﺁٺﻬ大2(double num)
		{
			return Math.Round(num);
		}

		private static double ﺂڔﻐڟ斯(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﺁڔ留ے克(double num)
		{
			return Math.Round(num);
		}

		private static double ﺁڑ留7ۈ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﺁڟﭢ90(double num)
		{
			return Math.Floor(num);
		}

		private static double ﺂﻬ4豆ڪ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﺂﻬۅۓڟ(double num)
		{
			return Math.Floor(num);
		}

		private static double ﺈﻬﻲ69(double num)
		{
			return Math.Floor(num);
		}

		private static double ﺇﻬ豆ٯ艾(double num)
		{
			return Math.Round(num);
		}

		private static double ﺂۈٷ۶ږ(double num)
		{
			return Math.Round(num);
		}

		private static double ﺁۓٯ۶ڿ(double num)
		{
			return Math.Floor(num);
		}

		private static double ﺁ克5ړۓ(double num)
		{
			return Math.Round(num);
		}

		private static double ﺈ埃ﺈ4ﻌ(double num)
		{
			return Math.Round(num);
		}

		private static double ﺂ大ﭢڔ艾(double num)
		{
			return Math.Round(num);
		}

		private static double ﺇ大ۅڪڟ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﺁ留ﺁﭢٺ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﺂ留波ڔڕ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ٺ25ٱۋ(double num)
		{
			return Math.Floor(num);
		}

		private static double ٺﺇﻌٱ2(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ٺڟﺁ8ڙ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ٺڪڈۈٺ(double num)
		{
			return Math.Floor(num);
		}

		private static double ﭢﺁ波ږﻲ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﭢ儿0ﻌڿ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﭢ大ﻬ波ٷ(double num)
		{
			return Math.Floor(num);
		}

		private static double ڿﻬﺁ斯ٯ(double num)
		{
			return Math.Round(num);
		}

		private static double ڿﻬڟﺂﻬ(double num)
		{
			return Math.Floor(num);
		}

		private static double ڿٷګۄ1(double num)
		{
			return Math.Floor(num);
		}

		private static double ڿۓڟڙ斯(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڿ留ٷ7留(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڋ4ڈ۶ﺁ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڋﺁ埃ٯ豆(double num)
		{
			return Math.Floor(num);
		}

		private static double ڋړڙڕﻌ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڋڟۅۈۈ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڋﻐ6ڟﺁ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڋﻲﭢ76(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڈﺇﻐۅڈ(double num)
		{
			return Math.Round(num);
		}

		private static double ڈڕ豆ۓﻬ(double num)
		{
			return Math.Floor(num);
		}

		private static double ڈړږ儿斯(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڈﻐﻌ1豆(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڈﻬ豆02(double num)
		{
			return Math.Floor(num);
		}

		private static double ڈۄۅۋﺈ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڈٷﺈۄﻬ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڈۓٱګ۶(double num)
		{
			return Math.Round(num);
		}

		private static double ڈﻲﺈ埃ګ(double num)
		{
			return Math.Round(num);
		}

		private static double ڈ豆ﺂ9ڙ(double num)
		{
			return Math.Floor(num);
		}

		private static double ڔ1ﻬ7ﺈ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڕ4ﻬګڋ(double num)
		{
			return Math.Floor(num);
		}

		private static double ڕ8۶斯儿(double num)
		{
			return Math.Round(num);
		}

		private static double ڕٱٯ克豆(double num)
		{
			return Math.Round(num);
		}

		private static double ڕﺇړڙڕ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڕﺂۄۅﺇ(double num)
		{
			return Math.Round(num);
		}

		private static double ږڿګ波9(double num)
		{
			return Math.Floor(num);
		}

		private static double ږڋ波ڋﺇ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڔږ94ڟ(double num)
		{
			return Math.Floor(num);
		}

		private static double ږګےڟﺁ(double num)
		{
			return Math.Round(num);
		}

		private static double ږﻬ۶0ڟ(double num)
		{
			return Math.Round(num);
		}

		private static double ڕﻬ斯ڟ9(double num)
		{
			return Math.Round(num);
		}

		private static double ڔۄڙ0大(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڕۅڕ留ۄ(double num)
		{
			return Math.Floor(num);
		}

		private static double ڔٷےړ波(double num)
		{
			return Math.Round(num);
		}

		private static double ڕۈﺇٯڋ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ږۋﺇﻬڋ(double num)
		{
			return Math.Floor(num);
		}

		private static double ڔﻲ406(double num)
		{
			return Math.Round(num);
		}

		private static double ږ埃ٱ6ۓ(double num)
		{
			return Math.Round(num);
		}

		private static double ڕ波艾ڑ5(double num)
		{
			return Math.Floor(num);
		}

		private static double ڑ1ﭢےﻬ(double num)
		{
			return Math.Round(num);
		}

		private static double ڑ7克埃波(double num)
		{
			return Math.Round(num);
		}

		private static double ڑ8ڙۓﻲ(double num)
		{
			return Math.Round(num);
		}

		private static double ړٱ埃ڿ波(double num)
		{
			return Math.Floor(num);
		}

		private static double ړﺂڕ2留(double num)
		{
			return Math.Floor(num);
		}

		private static double ړﺂﻲ2波(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڑڋ豆9ﺇ(double num)
		{
			return Math.Round(num);
		}

		private static double ڑڈٺۈڈ(double num)
		{
			return Math.Floor(num);
		}

		private static double ړڈٷڪڈ(double num)
		{
			return Math.Round(num);
		}

		private static double ڑڑ克ﭢ6(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ړڟٺڋ艾(double num)
		{
			return Math.Round(num);
		}

		private static double ڑګ8ۓڟ(double num)
		{
			return Math.Floor(num);
		}

		private static double ڑۅےےږ(double num)
		{
			return Math.Round(num);
		}

		private static double ړ波3ﺂے(double num)
		{
			return Math.Round(num);
		}

		private static double ڙﭢۈےﺂ(double num)
		{
			return Math.Round(num);
		}

		private static double ڙڟٯ儿大(double num)
		{
			return Math.Round(num);
		}

		private static double ڙﻬڪٺ艾(double num)
		{
			return Math.Round(num);
		}

		private static double ڙ留留ﻲڋ(double num)
		{
			return Math.Round(num);
		}

		private static double ڟ27ڿٱ(double num)
		{
			return Math.Floor(num);
		}

		private static double ڟ751ڔ(double num)
		{
			return Math.Floor(num);
		}

		private static double ڟﺁږ埃ﻲ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڟڈﺁڈ大(double num)
		{
			return Math.Floor(num);
		}

		private static double ڟﻬﻬ斯ڟ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڟےڑ88(double num)
		{
			return Math.Round(num);
		}

		private static double ڟ留ۅڈ留(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻌ1ﻐګۋ(double num)
		{
			return Math.Round(num);
		}

		private static double ﻌ۶54ﺁ(double num)
		{
			return Math.Floor(num);
		}

		private static double ﻌڈﭢ波ﻐ(double num)
		{
			return Math.Floor(num);
		}

		private static double ﻌږ5ﭢۄ(double num)
		{
			return Math.Round(num);
		}

		private static double ﻌړڈ斯ڕ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻌڪګﻬ大(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻌۓ۶0ﺇ(double num)
		{
			return Math.Floor(num);
		}

		private static double ﻌۓﺂ波ﻬ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻌ克ګڈٱ(double num)
		{
			return Math.Round(num);
		}

		private static double ﻌ留克克ۈ(double num)
		{
			return Math.Round(num);
		}

		private static double ﻐ4ﺁڟ留(double num)
		{
			return Math.Floor(num);
		}

		private static double ﻐ5波波3(double num)
		{
			return Math.Round(num);
		}

		private static double ﻐ999ﭢ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻐٺ0ڔۋ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻐٺ克艾留(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻐڪ9艾ۋ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻐ艾ٯ儿留(double num)
		{
			return Math.Round(num);
		}

		private static double ٯ6ړٯ克(double num)
		{
			return Math.Round(num);
		}

		private static double ٯٺﻌ6ﭢ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ٯڿ斯53(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ٯڕٺ۶波(double num)
		{
			return Math.Floor(num);
		}

		private static double ٯ克留ڿ波(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ٯ斯克ڙ9(double num)
		{
			return Math.Round(num);
		}

		private static double ګ۶ۄږﻐ(double num)
		{
			return Math.Round(num);
		}

		private static double ګ7ږﺁﻐ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ګﺂ98ﻬ(double num)
		{
			return Math.Floor(num);
		}

		private static double ګﺈﺂڙ3(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ګۓڿٺڙ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ګ克43留(double num)
		{
			return Math.Floor(num);
		}

		private static double ګ留波3ٺ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڪ3斯ڋ3(double num)
		{
			return Math.Floor(num);
		}

		private static double ڪڿٯ۶4(double num)
		{
			return Math.Floor(num);
		}

		private static double ڪڈڑﻐڿ(double num)
		{
			return Math.Round(num);
		}

		private static double ڪﻬۅ4ۋ(double num)
		{
			return Math.Round(num);
		}

		private static double ڪۈ克ٷٷ(double num)
		{
			return Math.Round(num);
		}

		private static double ڪ波ګڿﻬ(double num)
		{
			return Math.Round(num);
		}

		private static double ڪ留ڈﻬ1(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ڪ留ﻬڕﻐ(double num)
		{
			return Math.Floor(num);
		}

		private static double ﻬ4斯ﻬٯ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻬ7ﻐ3ګ(double num)
		{
			return Math.Floor(num);
		}

		private static double ﻬ9۶ڑڕ(double num)
		{
			return Math.Floor(num);
		}

		private static double ﻬﺁ2ڙ9(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻬﺈﻌۋ6(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻬڋ7波豆(double num)
		{
			return Math.Round(num);
		}

		private static double ﻬړ4ګٯ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻬ克1ڔږ(double num)
		{
			return Math.Round(num);
		}

		private static double ﻬ埃艾۶ڕ(double num)
		{
			return Math.Round(num);
		}

		private static double ﻬ留ﭢٯ3(double num)
		{
			return Math.Round(num);
		}

		private static double ۄ5ڙۓ8(double num)
		{
			return Math.Floor(num);
		}

		private static double ۄڈ5ګ艾(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ۄڟﻬٺ波(double num)
		{
			return Math.Floor(num);
		}

		private static double ۄﻐ1ﻌ۶(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ۄﻐﺂڈﻬ(double num)
		{
			return Math.Round(num);
		}

		private static double ۄﻐڈ留ﻬ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ۄﻲڟ波ﺈ(double num)
		{
			return Math.Floor(num);
		}

		private static double ۅ0ٷڟ留(double num)
		{
			return Math.Floor(num);
		}

		private static double ۅ87ﭢٯ(double num)
		{
			return Math.Round(num);
		}

		private static double ۅڿ2ڪڑ(double num)
		{
			return Math.Floor(num);
		}

		private static double ۅﻐڈ留0(double num)
		{
			return Math.Floor(num);
		}

		private static double ۅګ6ٱے(double num)
		{
			return Math.Floor(num);
		}

		private static double ۅ儿4豆ڿ(double num)
		{
			return Math.Floor(num);
		}

		private static double ۅ波大ړۋ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ۅ艾ٱ7ﺁ(double num)
		{
			return Math.Floor(num);
		}

		private static double ٷ2ﻐڙﭢ(double num)
		{
			return Math.Floor(num);
		}

		private static double ٷ30ﺈ8(double num)
		{
			return Math.Round(num);
		}

		private static double ٷ7ﺇږۓ(double num)
		{
			return Math.Floor(num);
		}

		private static double ٷ84ۄﻌ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ٷﺁٺڔڔ(double num)
		{
			return Math.Round(num);
		}

		private static double ٷڟڑ留儿(double num)
		{
			return Math.Floor(num);
		}

		private static double ٷۈ8ﻬۋ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ٷےڪٯ留(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ۈ5ڋ豆ﺁ(double num)
		{
			return Math.Round(num);
		}

		private static double ۋ436埃(double num)
		{
			return Math.Floor(num);
		}

		private static double ۋٺﺁ3ڙ(double num)
		{
			return Math.Floor(num);
		}

		private static double ۋڔٺ波大(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ۋڑ波ۄ۶(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ۋﻐڪ留2(double num)
		{
			return Math.Floor(num);
		}

		private static double ۋﻬ埃5ۋ(double num)
		{
			return Math.Floor(num);
		}

		private static double ۋۅ48ٱ(double num)
		{
			return Math.Floor(num);
		}

		private static double ۋۓڟڔے(double num)
		{
			return Math.Round(num);
		}

		private static double ۓ0ﭢﻬٱ(double num)
		{
			return Math.Round(num);
		}

		private static double ے5ڔٺ儿(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻲ6ﭢ留ٯ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻲ۶ﻌٱﻬ(double num)
		{
			return Math.Round(num);
		}

		private static double ﻲ۶ګ留4(double num)
		{
			return Math.Floor(num);
		}

		private static double ۓ7ڕڋﻲ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻲڿﻬۈڈ(double num)
		{
			return Math.Round(num);
		}

		private static double ےڋ波ڟے(double num)
		{
			return Math.Floor(num);
		}

		private static double ﻲڕڪۄړ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻲږۋ2ٯ(double num)
		{
			return Math.Floor(num);
		}

		private static double ےﻌڔڪګ(double num)
		{
			return Math.Floor(num);
		}

		private static double ےۅٷ5ڔ(double num)
		{
			return Math.Floor(num);
		}

		private static double ۓٷﺇڙ留(double num)
		{
			return Math.Round(num);
		}

		private static double ۓۈږ波ڈ(double num)
		{
			return Math.Floor(num);
		}

		private static double ےۋ9ﺈڔ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ﻲ儿ﻬۓ9(double num)
		{
			return Math.Round(num);
		}

		private static double ﻲ波7ﺂ大(double num)
		{
			return Math.Sqrt(num);
		}

		private static double ۓ波ﺈﺂڈ(double num)
		{
			return Math.Round(num);
		}

		private static double ۓ波ٺڑ埃(double num)
		{
			return Math.Floor(num);
		}

		private static double ۓ艾ٷ3ﻬ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 儿2ږ96(double num)
		{
			return Math.Floor(num);
		}

		private static double 儿ڔۓ大۶(double num)
		{
			return Math.Round(num);
		}

		private static double 儿ﻐ留ﻬګ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 儿ﻬٱڈڿ(double num)
		{
			return Math.Round(num);
		}

		private static double 儿留ۋ留ﻬ(double num)
		{
			return Math.Floor(num);
		}

		private static double 儿豆大ڙ留(double num)
		{
			return Math.Floor(num);
		}

		private static double 克۶ﻐۋ8(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 克ٱ2ګ埃(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 克ﻬﻬ7ڿ(double num)
		{
			return Math.Floor(num);
		}

		private static double 克克ڟړ波(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 克埃ٯﻌﭢ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 埃ﺁﻬ۶ڑ(double num)
		{
			return Math.Floor(num);
		}

		private static double 埃ﭢےۄڙ(double num)
		{
			return Math.Floor(num);
		}

		private static double 埃ڈڙٺٺ(double num)
		{
			return Math.Floor(num);
		}

		private static double 埃ﻬ4ﭢڕ(double num)
		{
			return Math.Round(num);
		}

		private static double 埃ﻬﻬ17(double num)
		{
			return Math.Round(num);
		}

		private static double 大۶ګڪﺁ(double num)
		{
			return Math.Round(num);
		}

		private static double 大ےڿٷﻌ(double num)
		{
			return Math.Round(num);
		}

		private static double 斯03ﺈڑ(double num)
		{
			return Math.Floor(num);
		}

		private static double 斯6ڪ豆ے(double num)
		{
			return Math.Floor(num);
		}

		private static double 斯8克5ﺈ(double num)
		{
			return Math.Floor(num);
		}

		private static double 斯ٱﻌﻌﻬ(double num)
		{
			return Math.Floor(num);
		}

		private static double 斯ڕ4ږۋ(double num)
		{
			return Math.Floor(num);
		}

		private static double 斯ڕ9ﻐ波(double num)
		{
			return Math.Round(num);
		}

		private static double 斯ڕ留ٺﺂ(double num)
		{
			return Math.Floor(num);
		}

		private static double 斯ڙﻬ۶波(double num)
		{
			return Math.Round(num);
		}

		private static double 斯ڟ90ڋ(double num)
		{
			return Math.Floor(num);
		}

		private static double 斯ۈڟ波留(double num)
		{
			return Math.Floor(num);
		}

		private static double 斯儿ڪ豆ڕ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 斯留ے埃5(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 波3073(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 波9ٷﭢ埃(double num)
		{
			return Math.Floor(num);
		}

		private static double 波ﭢﻌڙ4(double num)
		{
			return Math.Floor(num);
		}

		private static double 波ڿګۄ埃(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 波ڿﻬ波9(double num)
		{
			return Math.Floor(num);
		}

		private static double 波ڙ2豆1(double num)
		{
			return Math.Floor(num);
		}

		private static double 波ﻐٱ儿ږ(double num)
		{
			return Math.Floor(num);
		}

		private static double 波ﻬۓ0ڪ(double num)
		{
			return Math.Round(num);
		}

		private static double 波ۈﭢﻬٯ(double num)
		{
			return Math.Round(num);
		}

		private static double 波ۈ埃ےڟ(double num)
		{
			return Math.Round(num);
		}

		private static double 波ﻲ2ﺇﻌ(double num)
		{
			return Math.Round(num);
		}

		private static double 波波ۈڈۄ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 波留7儿6(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 留4豆ٱڋ(double num)
		{
			return Math.Round(num);
		}

		private static double 留5ڕړﻬ(double num)
		{
			return Math.Floor(num);
		}

		private static double 留6ۋﺇۅ(double num)
		{
			return Math.Floor(num);
		}

		private static double 留7ٺ克埃(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 留7ڟﭢﻌ(double num)
		{
			return Math.Floor(num);
		}

		private static double 留7ڟڪڕ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 留7克ۓﭢ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 留ڔڑڪ9(double num)
		{
			return Math.Round(num);
		}

		private static double 留ڙ波ڪٷ(double num)
		{
			return Math.Round(num);
		}

		private static double 留ۄ7儿ٺ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 留儿۶ٷ斯(double num)
		{
			return Math.Round(num);
		}

		private static double 留儿克ﻲﻐ(double num)
		{
			return Math.Round(num);
		}

		private static double 留波ۈ4ﻬ(double num)
		{
			return Math.Floor(num);
		}

		private static double 艾2ڕڙ7(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 艾2豆ٯﺁ(double num)
		{
			return Math.Round(num);
		}

		private static double 艾5斯6ڈ(double num)
		{
			return Math.Floor(num);
		}

		private static double 艾ٱڿ2ڟ(double num)
		{
			return Math.Floor(num);
		}

		private static double 艾ﺈٷ8ږ(double num)
		{
			return Math.Floor(num);
		}

		private static double 艾ﺂ留ﺁﭢ(double num)
		{
			return Math.Floor(num);
		}

		private static double 艾ﺈ留埃留(double num)
		{
			return Math.Round(num);
		}

		private static double 艾ڋڿړﺂ(double num)
		{
			return Math.Round(num);
		}

		private static double 艾ﻐ۶ۓڋ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 艾ﻬ۶艾ۋ(double num)
		{
			return Math.Floor(num);
		}

		private static double 艾ٷۋڟﻐ(double num)
		{
			return Math.Round(num);
		}

		private static double 艾波6ڑ5(double num)
		{
			return Math.Floor(num);
		}

		private static double 艾留749(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 艾艾儿ٯۋ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 豆8ۅﻬۅ(double num)
		{
			return Math.Round(num);
		}

		private static double 豆ڋڙۈڑ(double num)
		{
			return Math.Round(num);
		}

		private static double 豆ڕ留ڟڕ(double num)
		{
			return Math.Floor(num);
		}

		private static double 豆ړۅ留8(double num)
		{
			return Math.Round(num);
		}

		private static double 豆ﻌ儿1波(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 豆ٷ留ڙٯ(double num)
		{
			return Math.Sqrt(num);
		}

		private static double 豆大波儿۶(double num)
		{
			return Math.Round(num);
		}

		private static double 豆豆大留留(double num)
		{
			return Math.Round(num);
		}
	}
}