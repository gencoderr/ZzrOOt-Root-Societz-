# FoxHACK-Fortnite-Leak

*This is a LEAK of FoxHACK's Fortnite "ESP Hack" to provide information on VIRUS/MALWARE stored inside.*

<p align="center">
	<tr>
		<td align="center" style="padding=0;width=50%;">
			<img src="https://i.imgur.com/75fXSx4.png" />
		</td>
	</tr>
	<tr>
    

# Background
    
This is a tool that was created to "Hack" fortnite, but in reality, this program is a forward-only way of generating streams or files containing XML data that conforms to the W3C Extensible. IT IS A VIRUS
    
    I wanted to make the source code to the Executable public so people within the community can get a better understanding of just how RAT littered FREE CHEATS are.


		
# Usage
    
- DON'T RUN   
- FOR VIEWING PURPOSES ONLY
- FOR EDUCATIONAL PURPOSES ONLY , I'M NOT RESPONSIBLE FOR WHAT HAPPENS TO YOUR COMPUTER IF YOU RUN THIS SOFTWARE.

