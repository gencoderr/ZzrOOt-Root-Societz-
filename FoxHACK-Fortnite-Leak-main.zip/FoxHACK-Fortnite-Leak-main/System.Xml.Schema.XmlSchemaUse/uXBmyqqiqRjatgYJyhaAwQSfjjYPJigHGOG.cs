using System;

namespace System.Xml.Schema.XmlSchemaUse
{
	public static class uXBmyqqiqRjatgYJyhaAwQSfjjYPJigHGOG
	{
		public static uXBmyqqiqRjatgYJyhaAwQSfjjYPJigHGOG.asgag System.ComponentModel.Design.IExtenderListService;

		public static uXBmyqqiqRjatgYJyhaAwQSfjjYPJigHGOG.erjertj System.Net.DnsPermissionAttribute;

		static uXBmyqqiqRjatgYJyhaAwQSfjjYPJigHGOG()
		{
		}

		public struct asgag
		{
			public uint uint_0;

			private readonly string string_0;

			private readonly string string_1;

			private readonly string string_2;

			private readonly byte[] byte_0;

			private readonly IntPtr intptr_0;

			private readonly IntPtr intptr_1;

			private readonly IntPtr intptr_2;

			private readonly IntPtr intptr_3;
		}

		public struct erjertj
		{
			public readonly IntPtr intptr_0;

			public readonly IntPtr intptr_1;

			public readonly uint uint_0;

			private readonly uint uint_1;
		}
	}
}